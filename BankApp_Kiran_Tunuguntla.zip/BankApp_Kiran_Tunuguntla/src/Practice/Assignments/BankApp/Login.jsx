import React,{useState,useEffect} from 'react'
import axios from "axios";
import { Link,useNavigate } from "react-router-dom"


const Login = () => {
  const [name,setName]=useState({uname:'',pswrd:''})
  const [data, setData] = useState([]);
  const[find,setFound]=useState({found:'false'})
  const navigate = useNavigate();
  useEffect(() => {
    axios
      .get("http://localhost:3000/users") //connecting to JSON Server/External URL for get data.
      .then((res) => setData(res.data))
      .catch((err) => console.log(err));
  }, []);
  const validateLogin=(e)=>{
        if (name.uname!=="" && name.pswrd!==""){
      if(find.found=data.some(a=>a.email===name.uname))
      {
        navigate("/home",{state:{email:name.uname}})
        e.preventDefault();
      }
      else
      {
        alert('username/password not correct')
        e.preventDefault();
      }}
    else {
      alert("Username/Password is mandatory")

    }     
    
  }
  return (
    <div class="row d-flex justify-content-center align-items-center h-100">
    <div class="w-25 p-3" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
      <form method="post">
        <div class="row d-flex align-items-center justify-content-center h-100">
        <div class="col-md-8 col-lg-7 col-xl-6">
            <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg" class="img-fluid" alt="Phone image"/>
        </div>
        </div>
        <div data-mdb-input-init class="form-outline mb-4">
          <label for="uname" ></label>
          <input type="text" placeholder="Enter Username" value={name.uname} onChange={e=>setName({...name,uname:e.target.value})}  required id="form2Example1" class="form-control" />
        <div/>
        <div data-mdb-input-init class="form-outline mb-4">
            <label for="psw"></label>
          <input type="password" placeholder="Enter Password" name="pswrd" value={name.pswrd} onChange={e=>setName({...name,pswrd:e.target.value})} required id="form2Example2" class="form-control" />
        </div>
        
        </div>
        <div>
          
        </div>
        <ul class="nav nav-pills nav-justified mb-3" >
          <li>
          <button type="submit" onClick={validateLogin} data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-block mb-4">
            
            Login
        
      </button>
          </li>
          <li>
          <button type="button" class='btn btn-light' >
            <Link to="/Register">
              Sign Up
            </Link>
          </button>
          </li>
        </ul>


      </form>
    </div>
    </div>
  )
}

export default Login
