import React from 'react'
import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";


const Register = () => {

  const [Users, setUsers] = useState({
    firstName: '',
    lastName: '',
    age: '',
    gender: '',
    email: '',
    amount: ''
  })
  const handleSubmit = () => {
    axios
      .post("http://localhost:3000/users", Users)
      .then((res) => {
        console.log(res)
        navigate("/");
      })
      .catch((err) => console.log(err));

  }

  const navigate = useNavigate();
  return (

    <section class="vh-100 gradient-custom">
      <div class="container h-100">
        <div class="row justify-content-center align-items-center h-100">
         
            <div class="card shadow-2-strong card-registration">
              <div >
                <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Registration Form</h3>
                <form>
                  <div class="row justify-content-center"></div>
                  
                    
                    
                    <div data-mdb-input-init class="form-outline">
                      <label for="firstName"></label>
                      <input class="form-control form-control-lg" onChange={e => setUsers({ ...Users, firstName: e.target.value })} type="text" required placeholder="Enter first name" name="firstName" />
                    </div>

                    <div data-mdb-input-init class="form-outline">
                      <label for="lastName">  </label>
                      <input class="form-control form-control-lg" onChange={e => setUsers({ ...Users, lastName: e.target.value })} type="text" required placeholder="Enter last name" name="lastName"  />
                    </div>

                    <div data-mdb-input-init class="form-outline">
                      <label for="email"></label>
                      <input class="form-control form-control-lg" onChange={e => setUsers({ ...Users, email: e.target.value })} type="email" required placeholder="Enter Email" name="email" />
                    </div>

                    <div data-mdb-input-init class="form-outline">
                      <label for="age"></label>
                      <input class="form-control form-control-lg" onChange={e => setUsers({ ...Users, age: e.target.value })} type="number" required placeholder="Enter Age" name="age"/>
                    </div>

                    <div data-mdb-input-init class="form-outline">
                      <label for="amount"></label>
                      <input class="form-control form-control-lg" onChange={e => setUsers({ ...Users, amount: e.target.value })} type="number" required placeholder="Enter Amount" name="amount"  />
                    </div>

                    
                      <div class="form-check form-check-inline"><h6 class="mb-1 pb-1">Gender: </h6></div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" onChange={e => setUsers({ ...Users, gender: e.target.value })} id="Male" name="gender" value="Male" />
                        <label class="form-check-label" for="Male">Male</label><br />
                      </div>
                      <div class="form-check form-check-inline"> 
                      <input class="form-check-input" type="radio" onChange={e => setUsers({ ...Users, gender: e.target.value })} id="Female" name="gender" value="Female" />
                      <label class="form-check-label" for="Female">Female</label><br />
                      </div>
                      
                      
                      
                    

                    <div>
                      <button className="btn btn-primary" onClick={handleSubmit}>
                        Sign Up
                      </button>
                      <button className="btn btn-link">
                        <Link to="/" >Cancel</Link>
                      </button>
                    </div>
                  
                </form>
              </div>
            </div>
          </div>
        </div>
      
    </section>

  )
}

export default Register
